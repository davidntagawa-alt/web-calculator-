"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"
import { Send, ArrowLeft, Trash2 } from "lucide-react"
import Link from "next/link"

interface Message {
  id: string
  content: string
  role: "user" | "assistant"
  timestamp: Date
}

export default function AdminPage() {
  const [messages, setMessages] = useState<Message[]>([])
  const [replyInput, setReplyInput] = useState("")
  const [selectedMessageId, setSelectedMessageId] = useState<string | null>(null)

  useEffect(() => {
    const loadMessages = () => {
      const stored = localStorage.getItem("nadine-messages")
      if (stored) {
        const parsed = JSON.parse(stored)
        setMessages(parsed.map((m: any) => ({ ...m, timestamp: new Date(m.timestamp) })))
      }
    }

    loadMessages()
    const interval = setInterval(loadMessages, 2000)
    return () => clearInterval(interval)
  }, [])

  const handleReply = (messageId: string) => {
    if (!replyInput.trim()) return

    const replyMessage: Message = {
      id: Date.now().toString(),
      content: replyInput.trim(),
      role: "assistant",
      timestamp: new Date(),
    }

    const updatedMessages = [...messages, replyMessage]
    setMessages(updatedMessages)
    localStorage.setItem("nadine-messages", JSON.stringify(updatedMessages))
    setReplyInput("")
    setSelectedMessageId(null)
  }

  const handleClearAll = () => {
    if (confirm("Are you sure you want to clear all messages?")) {
      setMessages([])
      localStorage.removeItem("nadine-messages")
    }
  }

  const userMessages = messages.filter((m) => m.role === "user")
  const lastUserMessage = userMessages[userMessages.length - 1]

  return (
    <div className="min-h-screen bg-[#1a1a1a]">
      <header className="border-b border-white/10 bg-[#212121] px-6 py-4">
        <div className="mx-auto flex max-w-6xl items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon" className="text-white/70 hover:bg-white/10 hover:text-white">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-2xl font-semibold text-white">Admin Panel</h1>
          </div>
          <Button
            onClick={handleClearAll}
            variant="ghost"
            size="sm"
            className="text-red-400 hover:bg-red-500/10 hover:text-red-300"
          >
            <Trash2 className="mr-2 h-4 w-4" />
            Clear All
          </Button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-8">
        <div className="grid gap-6 lg:grid-cols-2">
          <Card className="border-white/10 bg-[#212121] p-6">
            <h2 className="mb-4 text-lg font-semibold text-white">Recent Messages</h2>
            <div className="space-y-4 max-h-[600px] overflow-y-auto">
              {messages.length === 0 ? (
                <p className="text-center text-white/50 py-8">No messages yet</p>
              ) : (
                messages.map((message) => (
                  <div
                    key={message.id}
                    className={`rounded-lg p-4 ${message.role === "user" ? "bg-[#2f2f2f]" : "bg-[#444654]"}`}
                  >
                    <div className="mb-2 flex items-center justify-between">
                      <span className="text-sm font-medium text-white">
                        {message.role === "user" ? "User" : "Nadine"}
                      </span>
                      <span className="text-xs text-white/40">{message.timestamp.toLocaleString()}</span>
                    </div>
                    <p className="whitespace-pre-wrap break-words text-white/90 leading-relaxed">{message.content}</p>
                  </div>
                ))
              )}
            </div>
          </Card>

          <Card className="border-white/10 bg-[#212121] p-6">
            <h2 className="mb-4 text-lg font-semibold text-white">Send Response</h2>
            {lastUserMessage ? (
              <div className="space-y-4">
                <div className="rounded-lg bg-[#2f2f2f] p-4">
                  <p className="mb-1 text-sm font-medium text-white">Last User Message:</p>
                  <p className="text-white/90 leading-relaxed">{lastUserMessage.content}</p>
                  <p className="mt-2 text-xs text-white/40">{lastUserMessage.timestamp.toLocaleString()}</p>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-white">Your Response:</label>
                  <Textarea
                    value={replyInput}
                    onChange={(e) => setReplyInput(e.target.value)}
                    placeholder="Type your response here..."
                    className="min-h-[200px] border-white/10 bg-[#2f2f2f] text-white placeholder:text-white/40 focus-visible:ring-white/20"
                  />
                </div>

                <Button
                  onClick={() => handleReply(lastUserMessage.id)}
                  disabled={!replyInput.trim()}
                  className="w-full bg-white text-black hover:bg-white/90"
                >
                  <Send className="mr-2 h-4 w-4" />
                  Send Response
                </Button>
              </div>
            ) : (
              <p className="text-center text-white/50 py-8">Waiting for user messages...</p>
            )}
          </Card>
        </div>

        <Card className="mt-6 border-white/10 bg-[#212121] p-6">
          <h2 className="mb-4 text-lg font-semibold text-white">Statistics</h2>
          <div className="grid gap-4 sm:grid-cols-3">
            <div className="rounded-lg bg-[#2f2f2f] p-4">
              <p className="text-sm text-white/60">Total Messages</p>
              <p className="text-2xl font-semibold text-white">{messages.length}</p>
            </div>
            <div className="rounded-lg bg-[#2f2f2f] p-4">
              <p className="text-sm text-white/60">User Messages</p>
              <p className="text-2xl font-semibold text-white">{messages.filter((m) => m.role === "user").length}</p>
            </div>
            <div className="rounded-lg bg-[#2f2f2f] p-4">
              <p className="text-sm text-white/60">Your Responses</p>
              <p className="text-2xl font-semibold text-white">
                {messages.filter((m) => m.role === "assistant").length}
              </p>
            </div>
          </div>
        </Card>
      </main>
    </div>
  )
}
